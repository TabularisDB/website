Tabularis brand kit
https://tabularis.dev/brand

LOGO / ICON
- color: for dark backgrounds
- white: for dark or colored backgrounds
- black: for light backgrounds
Please don't distort, recolor or crop the marks, and keep some space around them.

COLORS
Teal   #35D0C0
Blue   #2563EB
White  #FFFFFF
Black  #030712

FONTS (SIL Open Font License)
Urbanist         https://fonts.google.com/specimen/Urbanist
JetBrains Mono   https://fonts.google.com/specimen/JetBrains+Mono
